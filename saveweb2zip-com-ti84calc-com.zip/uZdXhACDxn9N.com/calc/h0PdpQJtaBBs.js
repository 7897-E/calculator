
function startTI84() {
    $("#calculatorDiv").draggable().draggable('disable')
    createCalculator("TI84");
    $("#calculatorDiv").css('position', 'static');
}

function startTI30() {
    $("#calculatorDiv").draggable().draggable('disable')
    createCalculator("TI30");
    $("#calculatorDiv").css('position', 'static');
}
